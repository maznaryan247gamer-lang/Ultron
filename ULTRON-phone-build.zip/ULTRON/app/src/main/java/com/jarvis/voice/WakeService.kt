package com.ultron.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class WakeService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_START = "com.ultron.voice.START"
        private const val CHANNEL = "ultron_voice_channel"
        private const val NOTIFICATION_ID = 1207
    }

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var active = false
    private var commandAfterWake = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else startForeground(NOTIFICATION_ID, notification())
            active = true
            startRecognition()
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.US
            tts?.setPitch(0.82f)
            tts?.setSpeechRate(0.88f)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "ULTRON voice listening", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Visible notification while the wake phrase listener is active"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ULTRON is listening")
            .setContentText("Say ‘Hey ULTRON’ or tap the notification to open the dashboard.")
            .setContentIntent(open).setOngoing(true).build()
    }

    private fun startRecognition() {
        if (!active) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this device.")
            stopSelf(); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { if (active) restartSoon() }
            override fun onResults(results: Bundle?) {
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                processSpeech(heard)
                if (active) restartSoon()
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val heard = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (heard.lowercase(Locale.US).contains("hey ultron")) {
                    commandAfterWake = true
                }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { restartSoon() }
    }

    private fun processSpeech(raw: String) {
        val text = raw.lowercase(Locale.US).trim()
        if (text.isBlank()) return
        val wakeIndex = text.indexOf("hey ultron")
        if (wakeIndex >= 0) {
            val command = text.substring(wakeIndex + "hey ultron".length).trim().trim(',', '.', ' ')
            if (command.isBlank()) {
                commandAfterWake = true
                speak("I'm listening.")
            } else executeCommand(command)
        } else if (commandAfterWake) {
            commandAfterWake = false
            executeCommand(text)
        }
    }

    private fun executeCommand(command: String) {
        commandAfterWake = false
        when {
            command.contains("open youtube") -> openApp("com.google.android.youtube", "Opening YouTube.")
            command.contains("open camera") || command == "camera" -> openApp("com.android.camera", "Opening camera.")
            command.contains("open settings") || command == "settings" -> {
                speak("Opening settings.")
                val i = Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { startActivity(i) }
            }
            command.contains("open chrome") || command.contains("open browser") -> openApp("com.android.chrome", "Opening your browser.")
            command.contains("go home") || command == "home" -> {
                val ok = UltronAccessibilityService.perform("home")
                speak(if (ok) "Returning to home screen." else "Enable ULTRON phone navigation in Accessibility settings first.")
            }
            command.contains("go back") || command == "back" -> {
                val ok = UltronAccessibilityService.perform("back")
                speak(if (ok) "Going back." else "Enable ULTRON phone navigation in Accessibility settings first.")
            }
            command.contains("stop listening") || command.contains("deactivate ultron") -> {
                speak("Voice listening deactivated.")
                stopSelf()
            }
            command.contains("what time") || command == "time" -> {
                val time = java.text.SimpleDateFormat("h:mm a", Locale.US).format(java.util.Date())
                speak("The time is $time.")
            }
            else -> speak("I heard $command. I can open YouTube, Chrome, camera, and settings, or navigate home and back.")
        }
    }

    private fun openApp(packageName: String, response: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            speak(response)
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { startActivity(launch) }
        } else speak("That app was not found. Try installing it or use the app launcher.")
    }

    private fun speak(message: String) {
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "ultron-${System.currentTimeMillis()}")
    }

    private fun restartSoon() {
        android.os.Handler(mainLooper).postDelayed({ if (active) startRecognition() }, 700)
    }

    override fun onDestroy() {
        active = false
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
