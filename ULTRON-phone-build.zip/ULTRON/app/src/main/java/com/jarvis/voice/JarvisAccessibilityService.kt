package com.ultron.voice

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class UltronAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile private var instance: UltronAccessibilityService? = null
        fun perform(action: String): Boolean {
            val service = instance ?: return false
            return when (action) {
                "home" -> service.performGlobalAction(GLOBAL_ACTION_HOME)
                "back" -> service.performGlobalAction(GLOBAL_ACTION_BACK)
                else -> false
            }
        }
    }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }
}
