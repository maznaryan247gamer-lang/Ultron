package com.ultron.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var listenButton: Button
    private var listening = false
    private val cyan = Color.rgb(55, 224, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3, 9, 18)
        window.navigationBarColor = Color.rgb(3, 9, 18)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LOW_PROFILE
        buildUi()
        requestNeededPermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 30, 28, 28)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(2, 8, 18), Color.rgb(5, 24, 42), Color.rgb(1, 5, 13)))
        }
        val brand = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            letterSpacing = .24f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL INTELLIGENCE SYSTEM  •  V1.0"
            textSize = 10f
            letterSpacing = .12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 116f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 18)
        }
        status = TextView(this).apply {
            text = "SYSTEM STANDBY"
            textSize = 15f
            letterSpacing = .15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val hint = TextView(this).apply {
            text = "Tap below to activate hands-free listening.\nSay: ‘Hey ULTRON, open YouTube.’"
            textSize = 14f
            setTextColor(Color.rgb(170, 196, 211))
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 26)
        }
        listenButton = Button(this).apply {
            text = "ACTIVATE ULTRON"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply {
                setColor(cyan); cornerRadius = 28f
            }
            setOnClickListener { toggleListening() }
        }
        val access = Button(this).apply {
            text = "ENABLE PHONE NAVIGATION"
            isAllCaps = false
            setTextColor(cyan)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT); cornerRadius = 24f; setStroke(1, cyan)
            }
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(brand, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(orb, LinearLayout.LayoutParams(-1, 230))
        root.addView(status, matchWrap())
        root.addView(hint, matchWrap())
        root.addView(listenButton, LinearLayout.LayoutParams(-1, 58))
        root.addView(access, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 12 })
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun requestNeededPermissions() {
        val missing = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS)
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 44)
    }

    private fun toggleListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions(); return
        }
        if (!listening) {
            val intent = Intent(this, WakeService::class.java).setAction(WakeService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            listening = true
            status.text = "LISTENING FOR ‘HEY ULTRON’"
            listenButton.text = "DEACTIVATE ULTRON"
        } else {
            stopService(Intent(this, WakeService::class.java))
            listening = false
            status.text = "SYSTEM STANDBY"
            listenButton.text = "ACTIVATE ULTRON"
        }
    }

    override fun onResume() {
        super.onResume()
        // The service owns the microphone while active; the notification remains visible.
    }
}
